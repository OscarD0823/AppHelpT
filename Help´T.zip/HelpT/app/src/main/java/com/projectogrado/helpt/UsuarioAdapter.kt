package com.projectogrado.helpt

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

// Definir el adaptador que se usará para mostrar la lista de usuarios
class UsuarioAdapter(
    private val usuarios: List<Pair<String, JSONObject>>, // Lista de usuarios con el documento y los datos
    private val onItemClick: (Pair<String, JSONObject>) -> Unit // Función lambda que manejará el clic en un ítem
) : RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {

    // Clase interna que representa el ViewHolder para cada ítem de la lista
    class UsuarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombreTextView: TextView = itemView.findViewById(R.id.tvNombreUsuario) // TextView para el nombre
        val documentoTextView: TextView = itemView.findViewById(R.id.tvDocumentoUsuario) // TextView para el documento
    }

    // Inflar el layout de cada ítem (item_usuario.xml)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_usuario, parent, false)
        return UsuarioViewHolder(view)
    }

    // Llenar los datos en cada ítem del RecyclerView
    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        val usuario = usuarios[position] // Obtener el usuario en la posición actual
        val nombre = usuario.second.getString("nombre") // Obtener el nombre del usuario desde el JSON
        val documento = usuario.first // El documento es la clave

        // Asignar los datos a los TextViews
        holder.nombreTextView.text = nombre
        holder.documentoTextView.text = documento

        // Configurar clic en el ítem
        holder.itemView.setOnClickListener {
            onItemClick(usuario) // Llamar a la función lambda al hacer clic en el usuario
        }
    }

    // Retornar el número de usuarios en la lista
    override fun getItemCount(): Int {
        return usuarios.size
    }
}
