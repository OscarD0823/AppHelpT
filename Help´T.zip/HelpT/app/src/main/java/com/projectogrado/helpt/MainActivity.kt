package com.projectogrado.helpt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val PREFERENCES_FILE = "credenciales"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        // Cargar credenciales desde SharedPreferences
        val sharedPreferences = getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)
        val users = loadUsers(sharedPreferences)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            // Validar las credenciales
            if (users.containsKey(email) && users[email] == password) {
                when (email) {
                    "admin" -> {
                        val intent = Intent(this, AdminActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    "doctor" -> {
                        val intent = Intent(this, DoctorActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    "paciente" -> {
                        val intent = Intent(this, PacienteActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    "responsable" -> {
                        val intent = Intent(this, ResponsableActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            } else {
                Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Función para cargar las credenciales de SharedPreferences
    private fun loadUsers(sharedPreferences: android.content.SharedPreferences): MutableMap<String, String> {
        val users = mutableMapOf<String, String>()
        users["admin"] = sharedPreferences.getString("admin", "admin") ?: "admin"
        users["doctor"] = sharedPreferences.getString("doctor", "doctor") ?: "doctor"
        users["paciente"] = sharedPreferences.getString("paciente", "paciente") ?: "paciente"
        users["responsable"] = sharedPreferences.getString("responsable", "responsable") ?: "responsable"
        return users
    }
}
