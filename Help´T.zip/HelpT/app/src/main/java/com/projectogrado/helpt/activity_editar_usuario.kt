package com.projectogrado.helpt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class EditarUsuarioActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etDocumento: EditText
    private lateinit var etTelefono: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnGuardar: Button

    private val PREFERENCES_FILE = "credenciales" // Archivo de SharedPreferences
    private var usuarioSeleccionado: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_usuario)

        // Vincular vistas
        etNombre = findViewById(R.id.etNombre)
        etDocumento = findViewById(R.id.etDocumento)
        etTelefono = findViewById(R.id.etTelefono)
        etPassword = findViewById(R.id.etPassword)
        btnGuardar = findViewById(R.id.btnGuardar)

        // Recibir el documento del usuario seleccionado de la actividad anterior
        usuarioSeleccionado = intent.getStringExtra("usuarioSeleccionado")

        // Cargar los datos si el usuario ha sido seleccionado
        usuarioSeleccionado?.let {
            cargarDatosUsuario(it)
        }

        // Guardar cambios cuando se presione el botón "Guardar"
        btnGuardar.setOnClickListener {
            guardarCambiosUsuario()
        }
    }

    private fun cargarDatosUsuario(documento: String) {
        // Cargar el usuario seleccionado desde SharedPreferences
        val sharedPreferences = getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)
        val userData = sharedPreferences.getString(documento, null)

        if (userData != null) {
            val jsonData = JSONObject(userData)
            etNombre.setText(jsonData.getString("nombre"))
            etDocumento.setText(documento)
            etTelefono.setText(jsonData.getString("telefono"))
            etPassword.setText(jsonData.getString("password"))
        } else {
            Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun guardarCambiosUsuario() {
        val newNombre = etNombre.text.toString().trim()
        val newDocumento = etDocumento.text.toString().trim()
        val newTelefono = etTelefono.text.toString().trim()
        val newPassword = etPassword.text.toString().trim()

        if (newNombre.isNotEmpty() && newDocumento.isNotEmpty() && newTelefono.isNotEmpty() && newPassword.isNotEmpty()) {
            val sharedPreferences = getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            // Si el documento ha cambiado, eliminar la entrada anterior
            if (usuarioSeleccionado != null && usuarioSeleccionado != newDocumento) {
                editor.remove(usuarioSeleccionado).apply()
            }

            // Crear un objeto JSON con los datos actualizados
            val updatedUserData = JSONObject().apply {
                put("nombre", newNombre)
                put("telefono", newTelefono)
                put("password", newPassword)
            }

            // Guardar los nuevos datos en SharedPreferences
            editor.putString(newDocumento, updatedUserData.toString())
            editor.apply()

            // Mostrar mensaje de éxito
            Toast.makeText(this, "Usuario actualizado correctamente", Toast.LENGTH_SHORT).show()

            // Volver a la actividad anterior (ModificarUsuarioActivity)
            val intent = Intent(this, ModificarUsuarioActivity::class.java)
            startActivity(intent)
            finish() // Cerrar la actividad actual
        } else {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }
}
