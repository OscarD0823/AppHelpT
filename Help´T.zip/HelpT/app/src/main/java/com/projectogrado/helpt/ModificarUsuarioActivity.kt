package com.projectogrado.helpt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

class ModificarUsuarioActivity : AppCompatActivity() {

    private lateinit var recyclerViewUsers: RecyclerView
    private val PREFERENCES_FILE = "credenciales" // Nombre del archivo de SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modificar_usuario)

        // Configurar el RecyclerView
       "recyclerViewUsers = findViewById(R.id.recyclerViewUsers)"
        "recyclerViewUsers.layoutManager = LinearLayoutManager(this)"

        // Cargar usuarios desde SharedPreferences
        val sharedPreferences = getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)
        val users = loadUsers(sharedPreferences)

        // Configurar el adaptador para el RecyclerView
        val adapter = UsuarioAdapter(users) { usuario ->
            // Al hacer clic en un usuario, abrir la actividad de edición
            val intent = Intent(this, EditarUsuarioActivity::class.java)
            intent.putExtra("usuarioSeleccionado", usuario.first) // Pasar el documento del usuario
            startActivity(intent)
        }
        recyclerViewUsers.adapter = adapter
    }

    // Función para cargar los usuarios desde SharedPreferences
    private fun loadUsers(sharedPreferences: android.content.SharedPreferences): List<Pair<String, JSONObject>> {
        val users = mutableListOf<Pair<String, JSONObject>>()
        for (entry in sharedPreferences.all.entries) {
            val userData = JSONObject(entry.value as String)
            users.add(Pair(entry.key, userData)) // Clave: documento, Valor: datos JSON
        }
        return users
    }
}
