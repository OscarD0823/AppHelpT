package com.projectogrado.helpt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class CrearUsuarioActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etDocumento: EditText
    private lateinit var etTelefono: EditText
    private lateinit var etAcudiente: EditText
    private lateinit var etFechaNacimiento: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnGuardarUsuario: Button
    private lateinit var btnVolver: Button

    // Nombre del archivo de SharedPreferences
    private val PREFERENCES_FILE = "credenciales"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_usuario)

        etNombre = findViewById(R.id.etNombre)
        etDocumento = findViewById(R.id.etDocumento)
        etTelefono = findViewById(R.id.etTelefono)
        etAcudiente = findViewById(R.id.etAcudiente)
        etFechaNacimiento = findViewById(R.id.etFechaNacimiento)
        etPassword = findViewById(R.id.etPassword)
        btnGuardarUsuario = findViewById(R.id.btnGuardarUsuario)
        btnVolver = findViewById(R.id.btnVolver)

        // Cargar las credenciales existentes de SharedPreferences
        val sharedPreferences = getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)

        // Botón para guardar el nuevo usuario
        btnGuardarUsuario.setOnClickListener {
            val nombre = etNombre.text.toString()
            val documento = etDocumento.text.toString()
            val telefono = etTelefono.text.toString()
            val acudiente = etAcudiente.text.toString()
            val fechaNacimiento = etFechaNacimiento.text.toString()
            val password = etPassword.text.toString()

            // Validar que todos los campos estén llenos
            if (nombre.isNotEmpty() && documento.isNotEmpty() && telefono.isNotEmpty() && acudiente.isNotEmpty() && fechaNacimiento.isNotEmpty() && password.isNotEmpty()) {
                // Verificar que el documento no exista ya como usuario
                if (sharedPreferences.contains(documento)) {
                    Toast.makeText(this, "El usuario ya existe", Toast.LENGTH_SHORT).show()
                } else {
                    // Crear un objeto JSON con los datos del usuario
                    val userData = JSONObject()
                    userData.put("nombre", nombre)
                    userData.put("telefono", telefono)
                    userData.put("acudiente", acudiente)
                    userData.put("fechaNacimiento", fechaNacimiento)
                    userData.put("password", password)

                    // Guardar los datos del usuario en SharedPreferences
                    val editor = sharedPreferences.edit()
                    editor.putString(documento, userData.toString()) // El documento es el usuario
                    editor.apply()

                    Toast.makeText(this, "Usuario creado exitosamente", Toast.LENGTH_SHORT).show()

                    // Limpiar los campos
                    etNombre.text.clear()
                    etDocumento.text.clear()
                    etTelefono.text.clear()
                    etAcudiente.text.clear()
                    etFechaNacimiento.text.clear()
                    etPassword.text.clear()
                }
            } else {
                Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Botón para volver al menú anterior
        btnVolver.setOnClickListener {
            val intent = Intent(this, AdminActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
